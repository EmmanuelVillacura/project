import { Leaf, Award, Sparkles } from 'lucide-react';

const values = [
  {
    icon: <Award size={32} />,
    title: 'Calidad',
    desc: 'Cada pieza pasa por un riguroso control de calidad. Usamos solo los mejores materiales y técnicas de fabricación que garantizan durabilidad y elegancia por décadas.',
  },
  {
    icon: <Leaf size={32} />,
    title: 'Sostenibilidad',
    desc: 'Trabajamos exclusivamente con maderas certificadas y procesos ecológicos. Nuestro compromiso con el medioambiente guía cada decisión de diseño y producción.',
  },
  {
    icon: <Sparkles size={32} />,
    title: 'Diseño Exclusivo',
    desc: 'Creamos piezas únicas que reflejan la personalidad de cada cliente. Nuestro equipo de diseñadores combina tendencias globales con la esencia artesanal argentina.',
  },
];

const team = [
  {
    name: 'Eduardo Sánchez',
    role: 'Fundador & Director General',
    image: 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=400&h=400&dpr=1',
  },
  {
    name: 'Valeria Moreno',
    role: 'Diseñadora Principal',
    image: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=400&h=400&dpr=1',
  },
  {
    name: 'Rodrigo Funes',
    role: 'Maestro Artesano',
    image: 'https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg?auto=compress&cs=tinysrgb&w=400&h=400&dpr=1',
  },
];

export default function QuienesSomos() {
  return (
    <main style={{ backgroundColor: '#F9F6F0' }}>
      {/* Hero banner */}
      <section
        style={{
          background: 'linear-gradient(135deg, #5C3A21 0%, #4A2E1A 100%)',
          color: '#F9F6F0',
        }}
        className="py-20 px-6 text-center"
      >
        <p
          style={{ color: '#C9A87C', fontFamily: '"Poppins", sans-serif' }}
          className="text-sm font-semibold uppercase tracking-widest mb-3"
        >
          15 años de tradición
        </p>
        <h1
          style={{ fontFamily: '"Playfair Display", serif' }}
          className="text-4xl md:text-5xl font-bold mb-4"
        >
          Nuestra Historia
        </h1>
        <div style={{ backgroundColor: '#C9A87C', height: '3px', width: '60px', margin: '0 auto' }} />
      </section>

      {/* History section */}
      <section className="py-20 px-6">
        <div className="max-w-6xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-14 items-center">
            {/* Text */}
            <div>
              <p
                style={{ color: '#B85C38', fontFamily: '"Poppins", sans-serif' }}
                className="text-sm font-semibold uppercase tracking-widest mb-3"
              >
                Quiénes somos
              </p>
              <h2
                style={{ fontFamily: '"Playfair Display", serif', color: '#3E2A1F' }}
                className="text-3xl font-bold mb-2"
              >
                Artesanía con alma argentina
              </h2>
              <div className="section-divider left mb-7" />

              <div className="space-y-5 text-base leading-relaxed" style={{ color: '#4E3528' }}>
                <p>
                  Muebles Edinson nació en 2009 como un pequeño taller familiar en Buenos Aires,
                  fundado por Eduardo Sánchez con una visión clara: crear muebles que trasciendan
                  las tendencias y se conviertan en el corazón de cada hogar. En 15 años de
                  trayectoria, crecimos hasta convertirnos en una de las marcas de referencia del
                  diseño de interiores en Argentina, sin perder jamás la esencia artesanal que
                  nos define.
                </p>
                <p>
                  Trabajamos de la mano de artesanos locales que heredaron el oficio de sus
                  familias. Cada unión, cada detalle, cada acabado refleja horas de dedicación
                  y un profundo respeto por el oficio. Nuestras piezas no se fabrican en serie:
                  se crean una a una, con la atención que merece cada cliente que confía en
                  nosotros para decorar su espacio.
                </p>
                <p>
                  Nuestro compromiso con el medioambiente nos llevó a certificar el 100% de las
                  maderas que utilizamos bajo estándares de silvicultura sostenible. Creemos que
                  la belleza y la responsabilidad ambiental no son opuestos, sino compañeros
                  naturales. Por eso, cada mueble que sale de nuestro taller lleva consigo la
                  promesa de un futuro mejor para las generaciones que vienen.
                </p>
              </div>
            </div>

            {/* Image */}
            <div className="relative">
              <div
                style={{
                  position: 'absolute',
                  top: '-16px',
                  left: '-16px',
                  right: '16px',
                  bottom: '16px',
                  backgroundColor: '#C9A87C',
                  borderRadius: '12px',
                  opacity: 0.25,
                  zIndex: 0,
                }}
              />
              <img
                src="https://images.pexels.com/photos/3932930/pexels-photo-3932930.jpeg?auto=compress&cs=tinysrgb&w=800&h=600&dpr=1"
                alt="Taller Muebles Edinson"
                style={{
                  borderRadius: '12px',
                  width: '100%',
                  height: '420px',
                  objectFit: 'cover',
                  boxShadow: '0 20px 50px rgba(62,42,31,0.2)',
                  position: 'relative',
                  zIndex: 1,
                }}
              />
              <div
                style={{
                  position: 'absolute',
                  bottom: '-20px',
                  right: '-20px',
                  backgroundColor: '#5C3A21',
                  color: '#F9F6F0',
                  borderRadius: '10px',
                  padding: '16px 24px',
                  zIndex: 2,
                  boxShadow: '0 8px 24px rgba(62,42,31,0.3)',
                }}
              >
                <p
                  style={{ fontFamily: '"Playfair Display", serif' }}
                  className="text-3xl font-bold"
                >
                  15+
                </p>
                <p className="text-xs uppercase tracking-wider mt-0.5" style={{ color: '#C9A87C' }}>
                  Años de experiencia
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Values */}
      <section style={{ backgroundColor: '#EDE8E0' }} className="py-20 px-6">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <p
              style={{ color: '#B85C38', fontFamily: '"Poppins", sans-serif' }}
              className="text-sm font-semibold uppercase tracking-widest mb-2"
            >
              Lo que nos mueve
            </p>
            <h2
              style={{ fontFamily: '"Playfair Display", serif', color: '#3E2A1F' }}
              className="text-4xl font-bold"
            >
              Nuestros Valores
            </h2>
            <div className="section-divider" />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {values.map((val, i) => (
              <div
                key={i}
                className="value-card bg-white rounded-xl p-8 text-center shadow-md"
                style={{ borderTop: '4px solid #C9A87C' }}
              >
                <div
                  style={{ color: '#B85C38' }}
                  className="flex justify-center mb-5"
                >
                  {val.icon}
                </div>
                <h3
                  style={{ fontFamily: '"Playfair Display", serif', color: '#3E2A1F' }}
                  className="text-xl font-bold mb-3"
                >
                  {val.title}
                </h3>
                <p style={{ color: '#6B5044' }} className="text-sm leading-relaxed">
                  {val.desc}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Team */}
      <section className="py-20 px-6" style={{ backgroundColor: '#F9F6F0' }}>
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <p
              style={{ color: '#B85C38', fontFamily: '"Poppins", sans-serif' }}
              className="text-sm font-semibold uppercase tracking-widest mb-2"
            >
              Las personas detrás de cada pieza
            </p>
            <h2
              style={{ fontFamily: '"Playfair Display", serif', color: '#3E2A1F' }}
              className="text-4xl font-bold"
            >
              Nuestro Equipo
            </h2>
            <div className="section-divider" />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-4xl mx-auto">
            {team.map((member, i) => (
              <div key={i} className="team-card text-center bg-white rounded-xl overflow-hidden shadow-md">
                <div style={{ overflow: 'hidden', height: '220px' }}>
                  <img
                    src={member.image}
                    alt={member.name}
                    style={{
                      width: '100%',
                      height: '100%',
                      objectFit: 'cover',
                      transition: 'transform 0.5s ease',
                    }}
                    onMouseEnter={(e) => (e.currentTarget.style.transform = 'scale(1.05)')}
                    onMouseLeave={(e) => (e.currentTarget.style.transform = 'scale(1)')}
                  />
                </div>
                <div className="p-5">
                  <h3
                    style={{ fontFamily: '"Playfair Display", serif', color: '#3E2A1F' }}
                    className="text-lg font-semibold mb-1"
                  >
                    {member.name}
                  </h3>
                  <p style={{ color: '#B85C38' }} className="text-sm font-medium">
                    {member.role}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </main>
  );
}
