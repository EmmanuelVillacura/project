import Carousel from '../components/Carousel';
import { ArrowRight } from 'lucide-react';

const products = [
  {
    name: 'Sofá Milano',
    description: 'Elegancia y confort en un diseño atemporal. Tapizado en cuero genuino con estructura de madera maciza.',
    image: 'https://images.pexels.com/photos/1866149/pexels-photo-1866149.jpeg?auto=compress&cs=tinysrgb&w=600&h=440&dpr=1',
  },
  {
    name: 'Mesa de Comedor Roble',
    description: 'Fabricada a mano con madera de roble sostenible. Capacidad para 8 personas, acabado natural mate.',
    image: 'https://images.pexels.com/photos/1350789/pexels-photo-1350789.jpeg?auto=compress&cs=tinysrgb&w=600&h=440&dpr=1',
  },
  {
    name: 'Cama Imperial',
    description: 'Cabecera tapizada en terciopelo, estructura reforzada. Disponible en todas las medidas estándar.',
    image: 'https://images.pexels.com/photos/1743229/pexels-photo-1743229.jpeg?auto=compress&cs=tinysrgb&w=600&h=440&dpr=1',
  },
  {
    name: 'Escritorio Ejecutivo',
    description: 'Diseño funcional con grandes superficies de trabajo, cajones deslizantes y terminaciones premium.',
    image: 'https://images.pexels.com/photos/667838/pexels-photo-667838.jpeg?auto=compress&cs=tinysrgb&w=600&h=440&dpr=1',
  },
];

interface InicioProps {
  onNavigate: (page: 'inicio' | 'quienes' | 'contacto') => void;
}

export default function Inicio({ onNavigate }: InicioProps) {
  return (
    <main>
      {/* Carousel */}
      <Carousel />

      {/* Featured products */}
      <section style={{ backgroundColor: '#F9F6F0' }} className="py-20 px-6">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <p
              style={{ color: '#B85C38', fontFamily: '"Poppins", sans-serif' }}
              className="text-sm font-semibold uppercase tracking-widest mb-2"
            >
              Selección especial
            </p>
            <h2
              style={{ fontFamily: '"Playfair Display", serif', color: '#3E2A1F' }}
              className="text-4xl font-bold"
            >
              Nuestros Productos Destacados
            </h2>
            <div className="section-divider" />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-7">
            {products.map((product, i) => (
              <div
                key={i}
                className="product-card bg-white rounded-xl shadow-md overflow-hidden"
                style={{ animationDelay: `${i * 0.1}s` }}
              >
                <div className="product-img-wrap">
                  <img src={product.image} alt={product.name} />
                </div>
                <div className="p-5">
                  <h3
                    style={{ fontFamily: '"Playfair Display", serif', color: '#3E2A1F' }}
                    className="text-lg font-semibold mb-2"
                  >
                    {product.name}
                  </h3>
                  <p style={{ color: '#6B5044' }} className="text-sm leading-relaxed mb-4">
                    {product.description}
                  </p>
                  <button
                    className="btn-primary text-sm"
                    onClick={() => onNavigate('contacto')}
                  >
                    Consultar
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Banner CTA */}
      <section
        style={{
          background: 'linear-gradient(135deg, #5C3A21 0%, #4A2E1A 100%)',
          color: '#F9F6F0',
        }}
        className="py-16 px-6"
      >
        <div className="max-w-3xl mx-auto text-center">
          <h2
            style={{ fontFamily: '"Playfair Display", serif' }}
            className="text-3xl md:text-4xl font-bold mb-4"
          >
            Diseñamos el espacio de tus sueños
          </h2>
          <p style={{ color: 'rgba(249,246,240,0.8)' }} className="text-lg mb-8 leading-relaxed">
            Más de 15 años creando muebles únicos con maderas sostenibles y artesanía local.
            Cada pieza, una obra de arte.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button
              className="btn-primary flex items-center gap-2 justify-center"
              onClick={() => onNavigate('contacto')}
            >
              Solicitar cotización <ArrowRight size={16} />
            </button>
            <button
              onClick={() => onNavigate('quienes')}
              style={{
                border: '2px solid #C9A87C',
                color: '#C9A87C',
                background: 'transparent',
                fontFamily: '"Poppins", sans-serif',
                fontWeight: 500,
                padding: '0.75rem 2rem',
                borderRadius: '4px',
                cursor: 'pointer',
                transition: 'all 0.3s ease',
              }}
              onMouseEnter={(e) => {
                (e.currentTarget as HTMLButtonElement).style.backgroundColor = '#C9A87C';
                (e.currentTarget as HTMLButtonElement).style.color = '#3E2A1F';
              }}
              onMouseLeave={(e) => {
                (e.currentTarget as HTMLButtonElement).style.backgroundColor = 'transparent';
                (e.currentTarget as HTMLButtonElement).style.color = '#C9A87C';
              }}
            >
              Conocer más
            </button>
          </div>
        </div>
      </section>

      {/* Features strip */}
      <section style={{ backgroundColor: '#F0EBE3' }} className="py-12 px-6">
        <div className="max-w-6xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-center">
            {[
              { icon: '🌿', title: 'Madera Sostenible', desc: 'Materiales certificados y responsables con el medioambiente' },
              { icon: '🛠️', title: 'Artesanía Local', desc: 'Cada mueble fabricado por artesanos argentinos con experiencia' },
              { icon: '✨', title: 'Diseño Exclusivo', desc: 'Piezas únicas adaptadas a la personalidad de tu hogar' },
            ].map((feat, i) => (
              <div key={i} className="py-4">
                <div className="text-4xl mb-3">{feat.icon}</div>
                <h3
                  style={{ fontFamily: '"Playfair Display", serif', color: '#3E2A1F' }}
                  className="text-lg font-semibold mb-1"
                >
                  {feat.title}
                </h3>
                <p style={{ color: '#6B5044' }} className="text-sm leading-relaxed">{feat.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </main>
  );
}
