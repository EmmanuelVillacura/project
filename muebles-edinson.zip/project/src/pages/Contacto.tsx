import { useState } from 'react';
import { Phone, Mail, MapPin, Clock, MessageCircle, Instagram, CheckCircle } from 'lucide-react';

interface FormState {
  nombre: string;
  email: string;
  telefono: string;
  mensaje: string;
}

export default function Contacto() {
  const [form, setForm] = useState<FormState>({ nombre: '', email: '', telefono: '', mensaje: '' });
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setForm((prev) => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      setSubmitted(true);
      setForm({ nombre: '', email: '', telefono: '', mensaje: '' });
    }, 1200);
  };

  return (
    <main style={{ backgroundColor: '#F9F6F0' }}>
      {/* Hero */}
      <section
        style={{ background: 'linear-gradient(135deg, #5C3A21 0%, #4A2E1A 100%)', color: '#F9F6F0' }}
        className="py-20 px-6 text-center"
      >
        <p
          style={{ color: '#C9A87C', fontFamily: '"Poppins", sans-serif' }}
          className="text-sm font-semibold uppercase tracking-widest mb-3"
        >
          Estamos aquí para ayudarte
        </p>
        <h1
          style={{ fontFamily: '"Playfair Display", serif' }}
          className="text-4xl md:text-5xl font-bold mb-4"
        >
          Contáctanos
        </h1>
        <div style={{ backgroundColor: '#C9A87C', height: '3px', width: '60px', margin: '0 auto' }} />
      </section>

      {/* Main content */}
      <section className="py-20 px-6">
        <div className="max-w-6xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-14">

            {/* Form */}
            <div>
              <h2
                style={{ fontFamily: '"Playfair Display", serif', color: '#3E2A1F' }}
                className="text-2xl font-bold mb-1"
              >
                Envianos un mensaje
              </h2>
              <div className="section-divider left mb-7" />

              {submitted ? (
                <div
                  style={{
                    backgroundColor: '#fff',
                    border: '2px solid #C9A87C',
                    borderRadius: '12px',
                    padding: '40px',
                    textAlign: 'center',
                  }}
                >
                  <CheckCircle size={48} style={{ color: '#C9A87C', margin: '0 auto 16px' }} />
                  <h3
                    style={{ fontFamily: '"Playfair Display", serif', color: '#3E2A1F' }}
                    className="text-xl font-semibold mb-2"
                  >
                    ¡Mensaje enviado!
                  </h3>
                  <p style={{ color: '#6B5044' }} className="text-sm leading-relaxed mb-6">
                    Gracias por comunicarte con nosotros. Te responderemos a la brevedad posible.
                  </p>
                  <button
                    className="btn-primary text-sm"
                    onClick={() => setSubmitted(false)}
                  >
                    Enviar otro mensaje
                  </button>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-5">
                  <div>
                    <label
                      htmlFor="nombre"
                      style={{ color: '#3E2A1F' }}
                      className="block text-sm font-medium mb-1.5"
                    >
                      Nombre completo <span style={{ color: '#B85C38' }}>*</span>
                    </label>
                    <input
                      id="nombre"
                      name="nombre"
                      type="text"
                      required
                      value={form.nombre}
                      onChange={handleChange}
                      placeholder="Tu nombre"
                      className="form-input"
                    />
                  </div>
                  <div>
                    <label
                      htmlFor="email"
                      style={{ color: '#3E2A1F' }}
                      className="block text-sm font-medium mb-1.5"
                    >
                      Correo electrónico <span style={{ color: '#B85C38' }}>*</span>
                    </label>
                    <input
                      id="email"
                      name="email"
                      type="email"
                      required
                      value={form.email}
                      onChange={handleChange}
                      placeholder="tu@email.com"
                      className="form-input"
                    />
                  </div>
                  <div>
                    <label
                      htmlFor="telefono"
                      style={{ color: '#3E2A1F' }}
                      className="block text-sm font-medium mb-1.5"
                    >
                      Teléfono
                    </label>
                    <input
                      id="telefono"
                      name="telefono"
                      type="tel"
                      value={form.telefono}
                      onChange={handleChange}
                      placeholder="+54 9 11 0000-0000"
                      className="form-input"
                    />
                  </div>
                  <div>
                    <label
                      htmlFor="mensaje"
                      style={{ color: '#3E2A1F' }}
                      className="block text-sm font-medium mb-1.5"
                    >
                      Mensaje <span style={{ color: '#B85C38' }}>*</span>
                    </label>
                    <textarea
                      id="mensaje"
                      name="mensaje"
                      required
                      rows={5}
                      value={form.mensaje}
                      onChange={handleChange}
                      placeholder="¿En qué podemos ayudarte?"
                      className="form-input resize-none"
                    />
                  </div>
                  <button
                    type="submit"
                    className="btn-primary w-full flex items-center justify-center gap-2"
                    disabled={loading}
                    style={{
                      opacity: loading ? 0.8 : 1,
                      cursor: loading ? 'not-allowed' : 'pointer',
                    }}
                  >
                    {loading ? (
                      <>
                        <svg className="animate-spin" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                          <path d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z" strokeOpacity="0.3" />
                          <path d="M21 12a9 9 0 00-9-9" />
                        </svg>
                        Enviando...
                      </>
                    ) : (
                      'Enviar mensaje'
                    )}
                  </button>
                </form>
              )}
            </div>

            {/* Contact info */}
            <div className="space-y-8">
              <div>
                <h2
                  style={{ fontFamily: '"Playfair Display", serif', color: '#3E2A1F' }}
                  className="text-2xl font-bold mb-1"
                >
                  Información de contacto
                </h2>
                <div className="section-divider left mb-7" />

                <ul className="space-y-5">
                  {[
                    {
                      icon: <Phone size={20} />,
                      label: 'Teléfono',
                      value: '+54 9 11 1234-5678',
                      href: 'tel:+5491112345678',
                    },
                    {
                      icon: <MessageCircle size={20} />,
                      label: 'WhatsApp',
                      value: '+54 9 11 1234-5678',
                      href: 'https://wa.me/5491112345678',
                    },
                    {
                      icon: <Mail size={20} />,
                      label: 'Correo electrónico',
                      value: 'info@mueblesedinson.com',
                      href: 'mailto:info@mueblesedinson.com',
                    },
                    {
                      icon: <Instagram size={20} />,
                      label: 'Instagram',
                      value: '@muebles.edinson',
                      href: 'https://instagram.com/muebles.edinson',
                    },
                    {
                      icon: <MapPin size={20} />,
                      label: 'Dirección',
                      value: 'Av. Corrientes 1234, CABA, Argentina',
                      href: null,
                    },
                  ].map((item, i) => (
                    <li key={i} className="flex items-start gap-4">
                      <div
                        style={{ backgroundColor: '#5C3A21', color: '#C9A87C' }}
                        className="w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0 mt-0.5"
                      >
                        {item.icon}
                      </div>
                      <div>
                        <p style={{ color: '#9A7060' }} className="text-xs font-medium uppercase tracking-wider mb-0.5">
                          {item.label}
                        </p>
                        {item.href ? (
                          <a
                            href={item.href}
                            target={item.href.startsWith('http') ? '_blank' : undefined}
                            rel="noopener noreferrer"
                            style={{ color: '#3E2A1F' }}
                            className="text-sm font-medium hover:text-amber-700 transition-colors"
                          >
                            {item.value}
                          </a>
                        ) : (
                          <p style={{ color: '#3E2A1F' }} className="text-sm font-medium">
                            {item.value}
                          </p>
                        )}
                      </div>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Hours */}
              <div
                style={{ backgroundColor: '#fff', borderLeft: '4px solid #C9A87C', borderRadius: '8px' }}
                className="p-6 shadow-sm"
              >
                <div className="flex items-center gap-2 mb-4">
                  <Clock size={18} style={{ color: '#B85C38' }} />
                  <h3
                    style={{ fontFamily: '"Playfair Display", serif', color: '#3E2A1F' }}
                    className="text-lg font-semibold"
                  >
                    Horario de atención
                  </h3>
                </div>
                <div className="space-y-1.5 text-sm" style={{ color: '#6B5044' }}>
                  <div className="flex justify-between">
                    <span>Lunes a Viernes</span>
                    <span className="font-medium">9:00 – 18:00 hs</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Sábados</span>
                    <span className="font-medium">10:00 – 14:00 hs</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Domingos</span>
                    <span className="font-medium" style={{ color: '#B85C38' }}>Cerrado</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Map */}
          <div className="mt-16">
            <h2
              style={{ fontFamily: '"Playfair Display", serif', color: '#3E2A1F' }}
              className="text-2xl font-bold mb-1"
            >
              Nuestra ubicación
            </h2>
            <div className="section-divider left mb-7" />
            <div
              style={{ borderRadius: '12px', overflow: 'hidden', boxShadow: '0 8px 32px rgba(62,42,31,0.15)' }}
            >
              <iframe
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3284.016559154463!2d-58.388!3d-34.603!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMzTCsDM2JzEwLjgiUyA1OMKwMjMnMTYuOCJX!5e0!3m2!1ses!2sar!4v1"
                width="100%"
                height="380"
                style={{ border: 0, display: 'block' }}
                allowFullScreen
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                title="Ubicación Muebles Edinson"
              />
            </div>
          </div>
        </div>
      </section>
    </main>
  );
}
