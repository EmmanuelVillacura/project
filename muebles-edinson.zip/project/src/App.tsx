import { useState, useEffect } from 'react';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import Inicio from './pages/Inicio';
import QuienesSomos from './pages/QuienesSomos';
import Contacto from './pages/Contacto';

type Page = 'inicio' | 'quienes' | 'contacto';

function getPageFromHash(): Page {
  const hash = window.location.hash.replace('#', '');
  if (hash === 'quienes' || hash === 'contacto') return hash;
  return 'inicio';
}

function App() {
  const [page, setPage] = useState<Page>(getPageFromHash);

  useEffect(() => {
    const onHashChange = () => setPage(getPageFromHash());
    window.addEventListener('hashchange', onHashChange);
    return () => window.removeEventListener('hashchange', onHashChange);
  }, []);

  const navigate = (target: Page) => {
    window.location.hash = target;
    setPage(target);
  };

  return (
    <div style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column', backgroundColor: '#F9F6F0' }}>
      <Navbar activePage={page} onNavigate={navigate} />
      <div style={{ flex: 1 }}>
        {page === 'inicio' && <Inicio onNavigate={navigate} />}
        {page === 'quienes' && <QuienesSomos />}
        {page === 'contacto' && <Contacto />}
      </div>
      <Footer onNavigate={navigate} />
    </div>
  );
}

export default App;
