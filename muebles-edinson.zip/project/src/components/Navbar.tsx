import { useState } from 'react';
import { Sofa, Menu, X } from 'lucide-react';

interface NavbarProps {
  activePage: 'inicio' | 'quienes' | 'contacto';
  onNavigate: (page: 'inicio' | 'quienes' | 'contacto') => void;
}

const links = [
  { key: 'inicio' as const, label: 'Inicio' },
  { key: 'quienes' as const, label: 'Quiénes Somos' },
  { key: 'contacto' as const, label: 'Contacto' },
];

export default function Navbar({ activePage, onNavigate }: NavbarProps) {
  const [menuOpen, setMenuOpen] = useState(false);

  const handleNav = (page: 'inicio' | 'quienes' | 'contacto') => {
    onNavigate(page);
    setMenuOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <nav style={{ backgroundColor: '#5C3A21' }} className="shadow-lg sticky top-0 z-50">
      <div className="max-w-6xl mx-auto px-6">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <button
            onClick={() => handleNav('inicio')}
            className="flex items-center gap-2.5 group"
          >
            <div
              style={{ backgroundColor: '#C9A87C' }}
              className="w-9 h-9 rounded flex items-center justify-center flex-shrink-0"
            >
              <Sofa size={20} color="#3E2A1F" />
            </div>
            <span
              style={{ fontFamily: '"Playfair Display", serif', color: '#F9F6F0' }}
              className="text-xl font-semibold tracking-wide leading-tight"
            >
              Muebles Edinson
            </span>
          </button>

          {/* Desktop links */}
          <div className="hidden md:flex items-center gap-8">
            {links.map((link) => (
              <button
                key={link.key}
                onClick={() => handleNav(link.key)}
                className={`nav-link ${activePage === link.key ? 'active' : ''}`}
              >
                {link.label}
              </button>
            ))}
          </div>

          {/* Mobile hamburger */}
          <button
            className="md:hidden text-white p-1"
            onClick={() => setMenuOpen((prev) => !prev)}
            aria-label="Menú"
          >
            {menuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>

      {/* Mobile menu */}
      <div className={`mobile-menu md:hidden ${menuOpen ? 'open' : ''}`}>
        <div
          style={{ backgroundColor: '#4A2E1A', borderTop: '1px solid rgba(201,168,124,0.2)' }}
          className="px-6 py-3 flex flex-col gap-1"
        >
          {links.map((link) => (
            <button
              key={link.key}
              onClick={() => handleNav(link.key)}
              className={`nav-link text-left py-3 border-b border-white/10 ${activePage === link.key ? 'active' : ''}`}
            >
              {link.label}
            </button>
          ))}
        </div>
      </div>
    </nav>
  );
}
