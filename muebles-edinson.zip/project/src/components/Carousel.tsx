import { useState, useEffect, useCallback } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';

const slides = [
  {
    url: 'https://images.pexels.com/photos/1571460/pexels-photo-1571460.jpeg?auto=compress&cs=tinysrgb&w=1400&h=700&dpr=1',
    title: 'Salas que inspiran',
    subtitle: 'Diseños modernos para momentos únicos',
  },
  {
    url: 'https://images.pexels.com/photos/1395967/pexels-photo-1395967.jpeg?auto=compress&cs=tinysrgb&w=1400&h=700&dpr=1',
    title: 'Comedores clásicos',
    subtitle: 'El arte de reunirse alrededor de una buena mesa',
  },
  {
    url: 'https://images.pexels.com/photos/164595/pexels-photo-164595.jpeg?auto=compress&cs=tinysrgb&w=1400&h=700&dpr=1',
    title: 'Dormitorios de lujo',
    subtitle: 'El descanso merece el mejor espacio',
  },
  {
    url: 'https://images.pexels.com/photos/1170412/pexels-photo-1170412.jpeg?auto=compress&cs=tinysrgb&w=1400&h=700&dpr=1',
    title: 'Oficinas ejecutivas',
    subtitle: 'Productividad y estilo en perfecta armonía',
  },
];

export default function Carousel() {
  const [current, setCurrent] = useState(0);
  const [animating, setAnimating] = useState(false);

  const goTo = useCallback((index: number) => {
    if (animating) return;
    setAnimating(true);
    setCurrent(index);
    setTimeout(() => setAnimating(false), 900);
  }, [animating]);

  const next = useCallback(() => {
    goTo((current + 1) % slides.length);
  }, [current, goTo]);

  const prev = useCallback(() => {
    goTo((current - 1 + slides.length) % slides.length);
  }, [current, goTo]);

  useEffect(() => {
    const timer = setInterval(next, 4000);
    return () => clearInterval(timer);
  }, [next]);

  return (
    <div className="carousel-container">
      {slides.map((slide, i) => (
        <div
          key={i}
          className={`carousel-slide ${i === current ? 'active' : ''}`}
          style={{
            backgroundImage: `url(${slide.url})`,
            backgroundSize: 'cover',
            backgroundPosition: 'center',
          }}
        >
          <div className="carousel-overlay" />
          <div className="absolute inset-0 flex items-center">
            <div className="max-w-6xl mx-auto px-10 w-full">
              <div className={`max-w-lg ${i === current ? 'animate-fade-in' : ''}`}>
                <h2
                  style={{
                    fontFamily: '"Playfair Display", serif',
                    color: '#F9F6F0',
                    textShadow: '0 2px 12px rgba(0,0,0,0.3)',
                  }}
                  className="text-4xl md:text-5xl font-bold leading-tight mb-3"
                >
                  {slide.title}
                </h2>
                <p
                  style={{ color: 'rgba(249,246,240,0.9)' }}
                  className="text-lg md:text-xl font-light mb-6"
                >
                  {slide.subtitle}
                </p>
              </div>
            </div>
          </div>
        </div>
      ))}

      {/* Prev / Next buttons */}
      <button
        onClick={prev}
        style={{ backgroundColor: 'rgba(92,58,33,0.75)', color: '#F9F6F0' }}
        className="absolute left-4 top-1/2 -translate-y-1/2 w-11 h-11 rounded-full flex items-center justify-center hover:bg-opacity-100 transition-all hover:scale-110 z-10"
        aria-label="Anterior"
      >
        <ChevronLeft size={22} />
      </button>
      <button
        onClick={next}
        style={{ backgroundColor: 'rgba(92,58,33,0.75)', color: '#F9F6F0' }}
        className="absolute right-4 top-1/2 -translate-y-1/2 w-11 h-11 rounded-full flex items-center justify-center hover:bg-opacity-100 transition-all hover:scale-110 z-10"
        aria-label="Siguiente"
      >
        <ChevronRight size={22} />
      </button>

      {/* Dots */}
      <div className="absolute bottom-5 left-1/2 -translate-x-1/2 flex gap-2.5 z-10">
        {slides.map((_, i) => (
          <button
            key={i}
            onClick={() => goTo(i)}
            className={`carousel-dot ${i === current ? 'active' : ''}`}
            aria-label={`Ir a imagen ${i + 1}`}
          />
        ))}
      </div>
    </div>
  );
}
