import { Sofa, MessageCircle, Instagram, Mail, Phone, Clock } from 'lucide-react';

interface FooterProps {
  onNavigate: (page: 'inicio' | 'quienes' | 'contacto') => void;
}

export default function Footer({ onNavigate }: FooterProps) {
  const handleNav = (page: 'inicio' | 'quienes' | 'contacto') => {
    onNavigate(page);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer style={{ backgroundColor: '#5C3A21', color: '#F9F6F0' }}>
      <div className="max-w-6xl mx-auto px-6 py-14">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-10">

          {/* Brand */}
          <div>
            <div className="flex items-center gap-2.5 mb-4">
              <div
                style={{ backgroundColor: '#C9A87C' }}
                className="w-9 h-9 rounded flex items-center justify-center flex-shrink-0"
              >
                <Sofa size={20} color="#3E2A1F" />
              </div>
              <span
                style={{ fontFamily: '"Playfair Display", serif' }}
                className="text-xl font-semibold"
              >
                Muebles Edinson
              </span>
            </div>
            <p className="text-sm leading-relaxed" style={{ color: 'rgba(249,246,240,0.75)' }}>
              Artesanía, calidad y diseño al servicio de tu hogar.
              Transformamos espacios en experiencias únicas.
            </p>
          </div>

          {/* Contact */}
          <div>
            <h4
              style={{ fontFamily: '"Playfair Display", serif', color: '#C9A87C' }}
              className="text-lg font-semibold mb-5"
            >
              Contacto
            </h4>
            <ul className="space-y-3 text-sm" style={{ color: 'rgba(249,246,240,0.85)' }}>
              <li>
                <a
                  href="https://wa.me/5491112345678"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2.5 hover:text-amber-300 transition-colors"
                >
                  <MessageCircle size={16} style={{ color: '#C9A87C' }} />
                  <span>+54 9 11 1234-5678</span>
                </a>
              </li>
              <li>
                <a
                  href="https://instagram.com/muebles.edinson"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2.5 hover:text-amber-300 transition-colors"
                >
                  <Instagram size={16} style={{ color: '#C9A87C' }} />
                  <span>@muebles.edinson</span>
                </a>
              </li>
              <li>
                <a
                  href="mailto:info@mueblesedinson.com"
                  className="flex items-center gap-2.5 hover:text-amber-300 transition-colors"
                >
                  <Mail size={16} style={{ color: '#C9A87C' }} />
                  <span>info@mueblesedinson.com</span>
                </a>
              </li>
              <li>
                <a
                  href="tel:+5491112345678"
                  className="flex items-center gap-2.5 hover:text-amber-300 transition-colors"
                >
                  <Phone size={16} style={{ color: '#C9A87C' }} />
                  <span>+54 9 11 1234-5678</span>
                </a>
              </li>
            </ul>
          </div>

          {/* Hours & Links */}
          <div>
            <h4
              style={{ fontFamily: '"Playfair Display", serif', color: '#C9A87C' }}
              className="text-lg font-semibold mb-5"
            >
              Horario de Atención
            </h4>
            <ul className="space-y-2 text-sm mb-6" style={{ color: 'rgba(249,246,240,0.85)' }}>
              <li className="flex items-start gap-2.5">
                <Clock size={15} className="mt-0.5 flex-shrink-0" style={{ color: '#C9A87C' }} />
                <div>
                  <p>Lun – Vie: 9:00 a 18:00 hs</p>
                  <p>Sáb: 10:00 a 14:00 hs</p>
                  <p>Dom: Cerrado</p>
                </div>
              </li>
            </ul>
            <h4
              style={{ fontFamily: '"Playfair Display", serif', color: '#C9A87C' }}
              className="text-base font-semibold mb-3"
            >
              Navegación
            </h4>
            <div className="flex flex-col gap-1.5 text-sm" style={{ color: 'rgba(249,246,240,0.85)' }}>
              {(['inicio', 'quienes', 'contacto'] as const).map((page) => {
                const labels = { inicio: 'Inicio', quienes: 'Quiénes Somos', contacto: 'Contacto' };
                return (
                  <button
                    key={page}
                    onClick={() => handleNav(page)}
                    className="text-left hover:text-amber-300 transition-colors w-fit"
                  >
                    {labels[page]}
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        <div
          style={{ color: 'rgba(249,246,240,0.5)', borderTop: '1px solid rgba(249,246,240,0.15)' }}
          className="mt-10 pt-6 text-center text-xs"
        >
          © {new Date().getFullYear()} Muebles Edinson. Todos los derechos reservados.
        </div>
      </div>
    </footer>
  );
}
